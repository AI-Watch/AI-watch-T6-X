var cross_sector = [
    "No"
]