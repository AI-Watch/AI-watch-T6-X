var uptake = [
    "Incremental \/ technical change",
    "Organizational \/ sustained change",
    "Transformative \/ disruptive"
]