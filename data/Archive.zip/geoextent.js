var geoextent = [
    "Local",
    "National",
    "Regional"
]