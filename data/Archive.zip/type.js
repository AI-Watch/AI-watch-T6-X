var type = [
    "Adjudication",
    "Enforcement",
    "Internal management",
    "Public services and engagement",
    "Regulatory research, analysis and monitoring"
]