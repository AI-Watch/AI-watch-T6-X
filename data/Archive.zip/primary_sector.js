var primary_sector = [
    "Defence",
    "Economic affairs",
    "General public services",
    "Health",
    "Housing and community amenities",
    "Public order and safety",
    "Recreation - culture and religion",
    "Social protection"
]