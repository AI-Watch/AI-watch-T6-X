var cross_border = [
    "No"
]