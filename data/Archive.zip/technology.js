var technology = [
    "Audio processing",
    "Chatbots - intelligent digital assistants - virtual agents and recommendation systems",
    "Cognitive robotics and process automation - connected and automated vehicles",
    "Computer vision and identity recognition",
    "Expert and rule based systems - algorithmic decision making",
    "Knowledge management and sentiment analysis - ai-empowered knowledge management",
    "Machine learning - deep learning",
    "Natural language processing - text mining and speech analytics",
    "Predictive analytics - simulation and data visualisation",
    "Security analytics and threat intelligence"
]